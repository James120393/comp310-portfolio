# comp310-portfolio

Student ID: 1506530

Controls

A = Move up
B = Breath Fire

Left = Move Left
Right = Move Right

Collect 10 gems to win
Do not get hit by an enemy or you will loose.

